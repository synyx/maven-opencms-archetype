#
# replacer = "${database}"
############################

CREATE DATABASE ${database} DEFAULT CHARACTER SET utf8;