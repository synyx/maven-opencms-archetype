#
# replacer = "${database}"
############################

CREATE DATABASE ${database};