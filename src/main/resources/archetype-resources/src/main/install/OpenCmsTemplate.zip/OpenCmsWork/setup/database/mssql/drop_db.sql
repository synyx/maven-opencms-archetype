#
# replacer = "${replacer}"
############################

DROP DATABASE ${database};
