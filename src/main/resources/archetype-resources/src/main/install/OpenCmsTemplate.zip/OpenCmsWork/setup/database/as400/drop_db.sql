# sadly i can not find any way to create a connection without having the database already created
#
# replacer = "${replacer}"
############################
#
#DEACTIVATE DATABASE ${database};
#DROP DATABASE ${database};
