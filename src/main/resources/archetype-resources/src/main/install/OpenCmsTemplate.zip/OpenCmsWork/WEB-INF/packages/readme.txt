Readme for moduledevelopers of OpenCms
######################################

In this folder (export) OpenCms stores all exported zip-files. You can put
your own exported zip-files here to import them via the database administration.
