#
# replacer = "${database}"
############################

DROP DATABASE ${database};

drop user ${user};
