Readme for moduledevelopers of OpenCms
######################################

In this folder (export/modules) OpenCms stores all exported modules. You can put
your own modules here to import them via the module administration.
