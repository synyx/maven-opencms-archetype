#
# replacer = "${replacer}"
############################

DROP USER ${user} CASCADE;
